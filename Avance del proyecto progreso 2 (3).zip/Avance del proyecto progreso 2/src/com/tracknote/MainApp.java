package com.tracknote;

import javax.swing.*;
import com.tracknote.manager.OrderManager;
import com.tracknote.manager.InventoryManager;
import com.tracknote.ui.OrderPanel;
import com.tracknote.ui.InventoryPanel;

public class MainApp {
    public static void main(String[] args) {
        InventoryManager invMgr  = new InventoryManager();
        OrderManager     ordMgr  = new OrderManager();

        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("TrackNote - Avance Proyecto II");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(900, 650);

            JTabbedPane tabs = new JTabbedPane();
            tabs.addTab("Pedidos",   new OrderPanel(ordMgr, invMgr));
            tabs.addTab("Inventario",new InventoryPanel(invMgr));
            frame.add(tabs);

            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    }
}
