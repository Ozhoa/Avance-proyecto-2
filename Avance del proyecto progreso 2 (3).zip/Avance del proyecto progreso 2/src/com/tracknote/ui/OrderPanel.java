package com.tracknote.ui;

import com.tracknote.manager.OrderManager;
import com.tracknote.manager.InventoryManager;
import com.tracknote.model.Order;
import com.tracknote.exception.OutOfStockException;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.util.Arrays;

public class OrderPanel extends JPanel {
    private OrderManager orderMgr;
    private InventoryManager invMgr;

    private JTextField idField;
    private JTextField clientField;
    private JTextField itemsField;
    private JTextField addressField;
    private JTextArea  log;

    public OrderPanel(OrderManager orderMgr, InventoryManager invMgr) {
        this.orderMgr = orderMgr;
        this.invMgr   = invMgr;
        initComponents();
    }

    private void initComponents() {
        setLayout(new BorderLayout(10,10));
        setBorder(new TitledBorder("Módulo Pedidos"));

        // --- Panel de inputs (2 filas x 4 columnas) ---
        JPanel inputPanel = new JPanel(new GridLayout(2, 4, 5, 5));
        idField      = new JTextField(6);
        clientField  = new JTextField(10);
        itemsField   = new JTextField(20);
        addressField = new JTextField(15);

        inputPanel.add(new JLabel("ID:"));
        inputPanel.add(idField);
        inputPanel.add(new JLabel("Cliente:"));
        inputPanel.add(clientField);

        inputPanel.add(new JLabel("Items (coma):"));
        inputPanel.add(itemsField);
        inputPanel.add(new JLabel("Dirección:"));
        inputPanel.add(addressField);

        // --- Panel de botones ---
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        JButton btnCreate = new JButton("Crear");
        JButton btnFind   = new JButton("Consultar");
        JButton btnUpdate = new JButton("Actualizar Estado");
        JButton btnDelete = new JButton("Eliminar");

        buttonPanel.add(btnCreate);
        buttonPanel.add(btnFind);
        buttonPanel.add(btnUpdate);
        buttonPanel.add(btnDelete);

        // --- Combinar inputs y botones ---
        JPanel north = new JPanel(new BorderLayout(0, 8));
        north.add(inputPanel,   BorderLayout.NORTH);
        north.add(buttonPanel,  BorderLayout.SOUTH);
        add(north, BorderLayout.NORTH);

        // --- Área de log ---
        log = new JTextArea(10, 40);
        log.setEditable(false);
        add(new JScrollPane(log), BorderLayout.CENTER);

        // --- Listeners ---
        btnCreate.addActionListener(e -> {
            Order o = new Order(
                    idField.getText().trim(),
                    clientField.getText().trim(),
                    Arrays.asList(itemsField.getText().split(",")),
                    addressField.getText().trim()
            );
            try {
                orderMgr.createOrder(o, invMgr);
                log.append("Creado: " + o + "\n");
            } catch (OutOfStockException ex) {
                JOptionPane.showMessageDialog(this,
                        ex.getMessage(),
                        "Stock insuficiente",
                        JOptionPane.WARNING_MESSAGE
                );
                log.append("Error: " + ex.getMessage() + "\n");
            }
        });

        btnFind.addActionListener(e -> {
            Order o = orderMgr.findById(idField.getText().trim());
            if (o != null) {
                log.append("Encontrado: " + o + "\n");
            } else {
                log.append("No existe ID: " + idField.getText().trim() + "\n");
            }
        });

        btnUpdate.addActionListener(e -> {
            String id = idField.getText().trim();
            boolean ok = orderMgr.updateStatus(id, Order.Status.ENVIADO);
            log.append(ok
                    ? "Estado ENVIADO para " + id + "\n"
                    : "No existe ID: " + id + "\n"
            );
        });

        btnDelete.addActionListener(e -> {
            String id = idField.getText().trim();
            boolean ok = orderMgr.deleteOrder(id);
            log.append(ok
                    ? "Eliminado: " + id + "\n"
                    : "No existe ID: " + id + "\n"
            );
        });
    }
}
