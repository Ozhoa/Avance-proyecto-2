// Archivo: src/com/tracknote/ui/InventoryPanel.java
package com.tracknote.ui;

import com.tracknote.manager.InventoryManager;
import com.tracknote.model.Product;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.util.Map;

public class InventoryPanel extends JPanel {
    private InventoryManager mgr;

    // Ya no hay skuField: usamos nameField como identificador
    private JTextField nameField;
    private JTextField qtyField;
    private JTextField catField;
    private JTextField priceField;
    private JTextField weightField;
    private JTextArea  log;

    public InventoryPanel(InventoryManager mgr) {
        this.mgr = mgr;
        initComponents();
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));
        setBorder(new TitledBorder("Módulo Inventario"));

        // --- Panel de inputs ---
        JPanel inputPanel = new JPanel(new GridLayout(3, 4, 5, 5));
        nameField   = new JTextField(10);
        qtyField    = new JTextField(4);
        catField    = new JTextField(8);
        priceField  = new JTextField(5);
        weightField = new JTextField(5);

        inputPanel.add(new JLabel("Nombre:"));
        inputPanel.add(nameField);
        inputPanel.add(new JLabel("Cantidad:"));
        inputPanel.add(qtyField);

        inputPanel.add(new JLabel("Categoría:"));
        inputPanel.add(catField);
        inputPanel.add(new JLabel("Precio:"));
        inputPanel.add(priceField);

        inputPanel.add(new JLabel("Peso:"));
        inputPanel.add(weightField);
        // casilla libre
        inputPanel.add(new JLabel());
        inputPanel.add(new JLabel());

        add(inputPanel, BorderLayout.NORTH);

        // --- Panel de botones ---
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        JButton btnAdd        = new JButton("Agregar");
        JButton btnFind       = new JButton("Consultar");
        JButton btnConsultAll = new JButton("Listado");
        JButton btnWithdraw   = new JButton("Retirar 1");

        buttonPanel.add(btnAdd);
        buttonPanel.add(btnFind);
        buttonPanel.add(btnConsultAll);
        buttonPanel.add(btnWithdraw);

        add(buttonPanel, BorderLayout.CENTER);

        // --- Área de log ---
        log = new JTextArea(8, 40);
        log.setEditable(false);
        add(new JScrollPane(log), BorderLayout.SOUTH);

        // --- Listeners ---
        btnAdd.addActionListener(e -> {
            try {
                String name = nameField.getText().trim();
                int    qty  = Integer.parseInt(qtyField.getText().trim());
                Product p = new Product(
                        /* sku ya no importa */ "",
                        name,
                        catField.getText().trim(),
                        Double.parseDouble(priceField.getText().trim()),
                        Double.parseDouble(weightField.getText().trim())
                );
                mgr.addProduct(p, qty);
                log.append("Agregado: " + name + " | Cantidad: " + qty + "\n");
            } catch (NumberFormatException ex) {
                log.append("Error: verifica cantidad, precio o peso (deben ser números)\n");
            }
        });

        btnFind.addActionListener(e -> {
            String name = nameField.getText().trim();
            Product p = mgr.findByName(name);
            if (p != null) {
                int stock = mgr.getStock(name);
                log.append("Encontrado: " + name + " | Stock: " + stock + "\n");
            } else {
                log.append("No existe producto: " + name + "\n");
            }
        });

        btnConsultAll.addActionListener(e -> {
            log.append("--- Inventario Completo ---\n");
            for (Map.Entry<String,Integer> en : mgr.getAllStock().entrySet()) {
                log.append(en.getKey() + " | Cantidad: " + en.getValue() + "\n");
            }
            log.append("---------------------------\n");
        });

        btnWithdraw.addActionListener(e -> {
            String name = nameField.getText().trim();
            if (mgr.removeStock(name, 1)) {
                log.append("Retirado 1 de " + name +
                        ". Quedan: " + mgr.getStock(name) + "\n");
            } else {
                log.append("No hay stock para " + name + "\n");
            }
        });
    }
}
