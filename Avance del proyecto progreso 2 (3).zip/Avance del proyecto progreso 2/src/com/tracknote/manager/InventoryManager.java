
package com.tracknote.manager;

import com.tracknote.model.Product;
import java.util.*;


public class InventoryManager {
    private Map<String, Product> products = new HashMap<>();
    private Map<String, Integer> stock   = new HashMap<>();


    public void addProduct(Product p, int quantity) {
        String name = p.getName().trim();
        products.put(name, p);
        stock.put(name, quantity);
    }


    public boolean removeStock(String name, int amount) {
        Integer q = stock.get(name);
        if (q == null || q < amount) return false;
        stock.put(name, q - amount);
        return true;
    }


    public int getStock(String name) {
        return stock.getOrDefault(name, 0);
    }


    public Map<String,Integer> getAllStock() {
        return new HashMap<>(stock);
    }


    public Product findByName(String name) {
        return products.get(name);
    }
}
