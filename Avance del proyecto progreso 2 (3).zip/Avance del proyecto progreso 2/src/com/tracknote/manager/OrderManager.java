package com.tracknote.manager;

import com.tracknote.model.Order;
import com.tracknote.exception.OutOfStockException;
import java.util.*;


public class OrderManager {
    private List<Order> orders = new ArrayList<>();
    private Queue<Order> processingQueue = new LinkedList<>();


    public void createOrder(Order o, InventoryManager invMgr) throws OutOfStockException {
        for (String sku : o.getItems()) {
            String key = sku.trim();
            if (!invMgr.removeStock(key, 1)) {
                throw new OutOfStockException(key);
            }
        }
        orders.add(o);
        processingQueue.offer(o);
    }


    public Order findById(String id) {
        return orders.stream()
                .filter(o -> o.getId().equals(id))
                .findFirst()
                .orElse(null);
    }


    public boolean updateStatus(String id, Order.Status newStatus) {
        Order o = findById(id);
        if (o != null) {
            o.setStatus(newStatus);
            return true;
        }
        return false;
    }


    public boolean deleteOrder(String id) {
        Order o = findById(id);
        if (o != null) {
            orders.remove(o);
            processingQueue.remove(o);
            return true;
        }
        return false;
    }


    public Order processNext() {
        Order o = processingQueue.poll();
        if (o != null) {
            o.setStatus(Order.Status.EN_PREPARACION);
        }
        return o;
    }


    public List<Order> getAllOrders() {
        return new ArrayList<>(orders);
    }
}
