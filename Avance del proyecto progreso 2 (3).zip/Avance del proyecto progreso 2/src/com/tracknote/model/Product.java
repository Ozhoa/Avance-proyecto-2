package com.tracknote.model;

public class Product {
    private String sku;
    private String name;
    private String category;
    private double price;
    private double weight;

    public Product(String sku, String name, String category, double price, double weight) {
        this.sku = sku;
        this.name = name;
        this.category = category;
        this.price = price;
        this.weight = weight;
    }

    // getters y setters
    public String getSku() { return sku; }
    public String getName() { return name; }
    public String getCategory() { return category; }
    public double getPrice() { return price; }
    public double getWeight() { return weight; }

    @Override
    public String toString() {
        return sku + ": " + name + " (" + category + ")";
    }
}
