package com.tracknote.model;

import java.util.List;

public class Order {
    public enum Status { PENDIENTE, EN_PREPARACION, ENVIADO, ENTREGADO, CANCELADO }

    private String id;
    private String clientName;
    private List<String> items;    // lista de SKUs o nombres
    private String address;
    private Status status;

    public Order(String id, String clientName, List<String> items, String address) {
        this.id = id;
        this.clientName = clientName;
        this.items = items;
        this.address = address;
        this.status = Status.PENDIENTE;
    }

    // getters y setters
    public String getId() { return id; }
    public String getClientName() { return clientName; }
    public List<String> getItems() { return items; }
    public String getAddress() { return address; }
    public Status getStatus() { return status; }
    public void setStatus(Status status) { this.status = status; }

    @Override
    public String toString() {
        return id + " | " + clientName + " | " + status;
    }
}
