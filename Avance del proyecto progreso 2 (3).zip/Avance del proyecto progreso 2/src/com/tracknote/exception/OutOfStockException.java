package com.tracknote.exception;

public class OutOfStockException extends Exception {
    public OutOfStockException(String sku) {
        super("No hay stock suficiente en el inventario: " + sku);
    }
}
