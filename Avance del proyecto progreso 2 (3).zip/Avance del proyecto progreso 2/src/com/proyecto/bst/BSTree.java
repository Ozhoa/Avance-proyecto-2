package com.proyecto.bst;

import java.util.*;

public class BSTree {
    private BSTNode root;


    public void insert(int value) {
        root = insertRec(root, value);
    }

    private BSTNode insertRec(BSTNode node, int value) {
        if (node == null) {
            return new BSTNode(value);
        }
        if (value < node.getValue()) {
            node.setLeft(insertRec(node.getLeft(), value));
        } else if (value > node.getValue()) {
            node.setRight(insertRec(node.getRight(), value));
        }
        return node;
    }


    public List<Integer> inOrder() {
        List<Integer> list = new ArrayList<>();
        traverse(root, list);
        return list;
    }

    private void traverse(BSTNode node, List<Integer> list) {
        if (node == null) {
            return;
        }
        traverse(node.getLeft(), list);
        list.add(node.getValue());
        traverse(node.getRight(), list);
    }
}
