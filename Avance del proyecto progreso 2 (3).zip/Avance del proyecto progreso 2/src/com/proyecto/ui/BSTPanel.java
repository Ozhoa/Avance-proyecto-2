package com.proyecto.ui;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import com.proyecto.bst.BSTree;

public class BSTPanel extends JPanel {
    private BSTree tree = new BSTree();
    private JTextField input = new JTextField(10);
    private JTextArea output = new JTextArea(10, 30);

    public BSTPanel() {
        setLayout(new BorderLayout(10, 10));
        JPanel top = new JPanel();
        top.add(new JLabel("Valor a insertar:"));
        top.add(input);
        JButton btnInsert = new JButton("Insertar");
        top.add(btnInsert);
        JButton btnTraverse = new JButton("Recorrido In-Orden");
        top.add(btnTraverse);
        add(top, BorderLayout.NORTH);

        output.setEditable(false);
        add(new JScrollPane(output), BorderLayout.CENTER);
        setBorder(new TitledBorder("Módulo BST"));

        btnInsert.addActionListener(e -> {
            try {
                int v = Integer.parseInt(input.getText());
                tree.insert(v);
                output.append("Insertado: " + v + "\n");
                input.setText("");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Ingrese un número entero");
            }
        });
        btnTraverse.addActionListener(e -> {
            output.append("In-Orden: " + tree.inOrder() + "\n");
        });
    }
}
