package com.proyecto.ui;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import com.proyecto.task.TaskManager;

public class TaskPanel extends JPanel {
    private TaskManager manager = new TaskManager();
    private JTextField taskInput = new JTextField(15);
    private JTextArea display = new JTextArea(10, 30);

    public TaskPanel() {
        setLayout(new BorderLayout(10, 10));
        JPanel top = new JPanel();
        top.add(new JLabel("Nueva Tarea:"));
        top.add(taskInput);
        JButton btnAdd = new JButton("Agregar");
        top.add(btnAdd);
        JButton btnProcess = new JButton("Procesar");
        top.add(btnProcess);
        JButton btnUndo = new JButton("Deshacer");
        top.add(btnUndo);
        add(top, BorderLayout.NORTH);

        display.setEditable(false);
        add(new JScrollPane(display), BorderLayout.CENTER);
        setBorder(new TitledBorder("Gestor de Tareas"));

        btnAdd.addActionListener(e -> {
            String t = taskInput.getText().trim();
            if (!t.isEmpty()) {
                manager.addTask(t);
                display.append("Agregada: " + t + "\n");
                taskInput.setText("");
            }
        });
        btnProcess.addActionListener(e -> {
            String t = manager.processTask();
            if (t != null) display.append("Procesada: " + t + "\n");
            else display.append("No hay tareas en cola\n");
        });
        btnUndo.addActionListener(e -> {
            String t = manager.undoLast();
            if (t != null) display.append("Deshecha: " + t + "\n");
            else display.append("Nada que deshacer\n");
        });
    }
}
