package com.proyecto;

import javax.swing.*;
import com.proyecto.ui.BSTPanel;
import com.proyecto.ui.TaskPanel;

public class MainApp {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Avance Proyecto - Programación III");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(800, 600);

            JTabbedPane tabs = new JTabbedPane();
            tabs.addTab("Módulo BST", new BSTPanel());
            tabs.addTab("Gestor de Tareas", new TaskPanel());
            frame.add(tabs);

            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    }
}
