package com.proyecto.task;

import java.util.*;

public class TaskManager {
    private Queue<String> queue = new LinkedList<>();
    private Deque<String> history = new LinkedList<>();


    public void addTask(String task) {
        queue.offer(task);
    }

    public String processTask() {
        String t = queue.poll();
        if (t != null) history.push(t);
        return t;
    }

    public String undoLast() {
        String last = history.poll();
        if (last != null) queue.offer(last);
        return last;
    }

    public boolean hasTasks() {
        return !queue.isEmpty();
    }
}
